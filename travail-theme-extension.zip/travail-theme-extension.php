<?php
/*
Plugin Name: Travail Theme Extension
Plugin URI: https://mage-people.com
Description: The Extension of the Travail theme - Extend your website features with Travail Theme Extension.
Version: 1.0
Author: MagePeople Team
Author URI: https://mage-people.com
Text Domain: travail-theme-extension
Domain Path: /languages/
*/

define( 'TRAVAIL_THEME_EXTENSION_VERSION', '1.0' );
define( 'TRAVAIL_THEME_EXTENSION__FILE__', __FILE__ );
define( 'TRAVAIL_THEME_EXTENSION_DIR_URL', plugin_dir_url( TRAVAIL_THEME_EXTENSION__FILE__ ) );
define( 'TRAVAIL_THEME_EXTENSION_INC', trailingslashit( TRAVAIL_THEME_EXTENSION_DIR_URL . 'inc' ) );
define( 'TRAVAIL_THEME_EXTENSION_ASSET', trailingslashit( TRAVAIL_THEME_EXTENSION_DIR_URL . 'asset' ) );

#-----------------------------------------------------------------
# Load Travail Metabox Functions
#-----------------------------------------------------------------

require_once('inc/travail-metabox.php' );

#-----------------------------------------------------------------
# Load Travail Mega-Menu Function
#-----------------------------------------------------------------

require_once('inc/travail-mega-menu.php' );

#-----------------------------------------------------------------
# Load Travail Enqueue Function
#-----------------------------------------------------------------

require_once('inc/travail-enqueue.php' );