<?php
namespace Travail\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class TravailRoundImageWidget extends Widget_Base {

	public function get_name() {
		return 'travail-round-image-widget';
	}

	public function get_title() {
		return __( 'Travail Round Image', 'travail-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return [ 'travail-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'travail_round_image_settings',
			[
				'label' => __( 'Travail Round Image Settings', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'travail_round_image',
			[
				'label' => __( 'Choose Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => 'https://travail.com/demo-one/wp-content/uploads/sites/2/2021/08/about-img-1.jpg',
				],
			]
		);

		$this->add_control(
			'travail_bg_animation_image',
			[
				'label' => __( 'Choose Background Animation Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => 'https://travail.com/demo-one/wp-content/uploads/sites/2/2021/08/shape-2.png',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'travail_round_image_border',
				'label' => __( 'Border', 'travail-elementor-kits' ),
				'selector' => '{{WRAPPER}} .travail-elementor-round-image-widget img',
			]
		);
	    $this->add_control(
	    	'travail_round_image_border_radius',
	    	 [
	    	 	'label' => __('Border Radius', 'travail-elementor-kits'), 
	    	 	'type' => Controls_Manager::DIMENSIONS, 
	    	 	'size_units' => ['px', '%'], 
	    	 	'selectors' => [
	    	 		'{{WRAPPER}} img ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	    	 	]
	    	]
	    );
        $this->add_group_control(
        	\Elementor\Group_Control_Box_Shadow::get_type(), 
        	[
        		'name' => 'travail_round_image_box_shadow', 
        		'selector' => '{{WRAPPER}}  img',
        	]
        );

		$this->add_control(
			'travail_round_image_width',
			[
				'label' => __( 'Image Size', 'travail-elementor-kits' ),
				'description' => __( 'Example: 100px or 50%', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => '400px',
	    	 	'selectors' => [
	    	 		'{{WRAPPER}} img ' => 'width: {{VALUE}}',
	    	 	]
			]
		);

		$this->add_control(
			'travail_animated_image_rotatation_start',
			[
				'label' => __( 'Animated image Rotatation Start From Degree', 'travail-elementor-kits' ),
				'description' => __( 'Example: 0deg', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => '0deg'
			]
		);
		$this->add_control(
			'travail_animated_image_rotatation_end',
			[
				'label' => __( 'Animated image Rotatation End To Degree', 'travail-elementor-kits' ),
				'description' => __( 'Example: 5deg or -5deg', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => '5deg'
			]
		);
        $this->end_controls_section();
	
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$travail_round_image = $settings['travail_round_image']['url'];
		$travail_bg_animation_image = $settings['travail_bg_animation_image']['url'];
		$travail_animated_image_rotatation_start = $settings['travail_animated_image_rotatation_start'];
		$travail_animated_image_rotatation_end = $settings['travail_animated_image_rotatation_end'];

		if($travail_bg_animation_image){
			echo "
			<style>
            {{WRAPPER}} .travail-elementor-round-image-widget:before{background-image:url(".$travail_bg_animation_image.");}
			</style>
			";
		}
		if($travail_animated_image_rotatation_start && $travail_animated_image_rotatation_end){
			echo "
			<style>
				@keyframes dizzling{
				    0%{
				        -webkit-transform: rotate(".$travail_animated_image_rotatation_start.");
				        -moz-transform: rotate(".$travail_animated_image_rotatation_start.");
				        -ms-transform: rotate(".$travail_animated_image_rotatation_start.");
				        -o-transform: rotate(".$travail_animated_image_rotatation_start.");
				        transform: rotate(".$travail_animated_image_rotatation_start.");
				    }
				    50%{
				        -webkit-transform: rotate(".$travail_animated_image_rotatation_end.");
				        -moz-transform: rotate(".$travail_animated_image_rotatation_end.");
				        -ms-transform: rotate(".$travail_animated_image_rotatation_end.");
				        -o-transform: rotate(".$travail_animated_image_rotatation_end.");
				        transform: rotate(".$travail_animated_image_rotatation_end.");
				    }
				    100%{
				        -webkit-transform: rotate(".$travail_animated_image_rotatation_start."0);
				        -moz-transform: rotate(".$travail_animated_image_rotatation_start.");
				        -ms-transform: rotate(".$travail_animated_image_rotatation_start.");
				        -o-transform: rotate(".$travail_animated_image_rotatation_start.");
				        transform: rotate(".$travail_animated_image_rotatation_start.");
				    }
				}            
			</style>
			";
		}
	?>

	<div class="travail-elementor-round-image-widget">
		<img src="<?php echo esc_url($travail_round_image); ?>"/>
	</div>
	<?php
}

}
