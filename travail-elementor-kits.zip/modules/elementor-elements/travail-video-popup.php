<?php
namespace Travail\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class TravailVideoPopupWidget extends Widget_Base {

	public function get_name() {
		return 'travail-video-popup-widget';
	}

	public function get_title() {
		return __( 'Travail Video Popup', 'travail-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-play';
	}

	public function get_categories() {
		return [ 'travail-elements' ];
	}

	protected function _register_controls() {

/******************************************************************
Travail Video Popup Settings
*******************************************************************/

		$this->start_controls_section(
			'travail_video_popup_settings',
			[
				'label' => __( 'Travail Video Popup Settings', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_video_popup_type',
			[
				'label' 		=> __( 'Choose Video Type', 'travail-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'youtube',				
				'options' 		=> [
					'youtube' 	=> __( 'Youtube', 'travail-elementor-kits' ),
					'vimeo' 	=> __( 'Vimeo', 'travail-elementor-kits' ),
				],
			]
		);
		$this->add_control(
			'travail_video_popup_youtube_id',
			[
				'label' 		=> __( 'Youtube Video ID', 'travail-elementor-kits' ),
				'type' 			=> Controls_Manager::TEXT,
				'placeholder' 	=> __( 'aqz-KE-bpKQ', 'travail-elementor-kits' ),
				'default' 		=> __( 'aqz-KE-bpKQ', 'travail-elementor-kits' ),
				'condition' 	=> ['travail_video_popup_type' => 'youtube'],
			]
		);
		$this->add_control(
			'travail_video_popup_vimeo_id',
			[
				'label' 		=> __( 'Vimeo Video ID', 'travail-elementor-kits' ),
				'type' 			=> Controls_Manager::TEXT,
				'placeholder' 	=> __( '588496072', 'travail-elementor-kits' ),
				'default' 		=> __( '588496072', 'travail-elementor-kits' ),
				'condition' 	=> ['travail_video_popup_type' => 'vimeo'],
			]
		);
		$this->add_control(
			'travail_video_popup_icon',
			[
				'label' 		=> __( 'Choose Icon', 'travail-elementor-kits' ),
				'type' 			=> Controls_Manager::ICONS,
				'default' 		=> [
					'value' 	=> 'flaticon flaticon-play-button-3',
					'library' 	=> 'travail-icons',
				],
			]
		);															
        $this->end_controls_section();

		$this->start_controls_section(
			'travail_video_popup_style',
			[
				'label' => __( 'Travail Video Popup Style', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'travail_video_popup_icon_color',
			[
				'label' => __( 'Icon Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-video-popup-widget i' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'travail_video_popup_icon_bg',
			[
				'label' => __( 'Icon Background', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-video-popup-widget i' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'travail_video_popup_icon_font_size',
			[
				'label' => __( 'Icon Font Size', 'travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-video-popup-widget i' => 'font-size: {{VALUE}}px;',
				],
			]
		);
		$this->add_responsive_control(
			'travail_video_popup_icon_width',
			[
				'label' => __( 'Icon Width (px)', 'travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-video-popup-widget i' => 'width: {{VALUE}}px;height: {{VALUE}}px;line-height: {{VALUE}}px',
					'.travail-elementor-video-popup-widget .link-lightbox .ripple' => 'width: {{VALUE}}px;height: {{VALUE}}px',
					'.travail-elementor-video-popup-widget .link-lightbox .ripple:before' => 'width: {{VALUE}}px;height: {{VALUE}}px',
					'.travail-elementor-video-popup-widget .link-lightbox .ripple:after' => 'width: {{VALUE}}px;height: {{VALUE}}px',
				],
			]
		);												
        $this->end_controls_section();		        
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$travail_video_popup_type = $settings['travail_video_popup_type'];
		$travail_video_popup_youtube_id = $settings['travail_video_popup_youtube_id'];
		$travail_video_popup_vimeo_id = $settings['travail_video_popup_vimeo_id'];
		$travail_video_popup_icon = $settings['travail_video_popup_icon']['value'];
	?>

	<div class="travail-elementor-video-popup-widget">
	<?php if($travail_video_popup_type == 'youtube') { ?>

		<a href="#" class="link-lightbox" data-videoid="<?php echo esc_attr($travail_video_popup_youtube_id); ?>" data-videosite="youtube"><i class="<?php echo $travail_video_popup_icon; ?>"></i><span class="ripple"></span></a>

	<?php } else { ?>

		<a href="#" class="link-lightbox" data-videoid="<?php echo esc_attr($travail_video_popup_vimeo_id); ?>" data-videosite="vimeo"><i class="<?php echo $travail_video_popup_icon; ?>"></i><span class="ripple"></span></a>

	<?php } ?>
	</div>

	<?php
}

}
