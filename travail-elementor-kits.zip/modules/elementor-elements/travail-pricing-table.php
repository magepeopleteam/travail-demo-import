<?php
namespace Travail\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Background;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class TravailPricingTableWidget extends Widget_Base {

	public function get_name() {
		return 'travail-pricing-table-widget';
	}

	public function get_title() {
		return __( 'Travail Pricing Table', 'travail-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-price-table';
	}

	public function get_categories() {
		return [ 'travail-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'travail_pricing_table_settings',
			[
				'label' => __( 'Travail Pricing Table Settings', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_name',
			[
				'label' => __( 'Plan Name', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter plan name', 'travail-elementor-kits' ),
				'default' => __( 'Day Pass', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_currency',
			[
				'label' => __( 'Plan Currency', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter plan currency', 'travail-elementor-kits' ),
				'default' => __( '$', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_price',
			[
				'label' => __( 'Plan Price', 'travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'placeholder' => __( 'Enter plan price', 'travail-elementor-kits' ),
				'default' => __( '35.99', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_duration',
			[
				'label' => __( 'Plan Duration', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( '/ per month', 'travail-elementor-kits' ),
				'default' => __( '', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_enable_features',
			[
				'label' => __( 'Plan Enable Features', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter enable features', 'travail-elementor-kits' ),
				'default' => __( 'Conference Tickets,Free Lunch And Coffee,Certificate', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_disable_features',
			[
				'label' => __( 'Plan Disable Features', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter disable features', 'travail-elementor-kits' ),
				'default' => __( 'Easy Access,Free Contacts', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_btn_name',
			[
				'label' => __( 'Plan Button Label', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter button label', 'travail-elementor-kits' ),
				'default' => __( 'Buy Ticket', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_btn_url',
			[
				'label' => __( 'Plan Button URL', 'travail-elementor-kits' ),
				'type' => Controls_Manager::URL,
				'placeholder' => __( 'https://', 'travail-elementor-kits' ),
				'default' => [
					'url' => '#',
					'is_external' => true,
				],
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_card_icon',
			[
				'label' => __( 'Plan Card Icon', 'travail-elementor-kits' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'flaticon flaticon-rocket-ship',
					'library' => 'travail-icons',
				],
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_header_bg_image',
			[
				'label' => __( 'Plan Header Background Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => TRAVAIL_ELEMENTOR_KITS_ASSETS . 'images/pricing-table-header-bg.jpg',
				],
			]
		);		
		$this->add_control(
			'travail_pricing_table_plan_body_bg_image',
			[
				'label' => __( 'Plan Body Background Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => TRAVAIL_ELEMENTOR_KITS_ASSETS . 'images/pricing-table-body-bg.jpg',
				],
			]
		);														
        $this->end_controls_section();
		$this->start_controls_section(
			'travail_pricing_table_style',
			[
				'label' => __( 'Travail Pricing Table Style', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'travail_pricing_table_header_icon_switch',
			[
				'label'   => __( 'On/Off Header Icon', 'travail-elementor-kits' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'block',
				'options' => [
					'block'  => 'On',
					'none' => 'Off'
				],
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .card-image' => 'display: {{VALUE}};',
				],
			]
		);		
		$this->add_control(
			'travail_pricing_table_header_icon_color',
			[
				'label' => __( 'Header Icon Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .card-image i' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'travail_pricing_table_header_icon_bg_color',
			[
				'label' => __( 'Header Icon Background Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .card-image i' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'travail_pricing_table_header_icon_border_color',
			[
				'label' => __( 'Header Icon Border Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .card-image i' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'travail_pricing_table_header_icon_size',
			[
				'label' => __( 'Header Icon Size (px)', 'travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .card-image i' => 'font-size: {{VALUE}}px;',
				],
			]
		);
		$this->add_control(
			'travail_pricing_table_header_icon_wrapper_width',
			[
				'label' => __( 'Header Icon Wrapper Width (px)', 'travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .card-image i' => 'width: {{VALUE}}px;height: {{VALUE}}px;line-height:{{VALUE}}px',
				],
			]
		);			
		$this->add_control(
			'divider1',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_name_color',
			[
				'label' => __( 'Plan Label Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .plan-name' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_pricing_table_plan_name_typography',
				'label' => __( 'Plan Label Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-elementor-pricing-table-widget .plan-name',
			]
        );
		$this->add_control(
			'divider2',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_currency_color',
			[
				'label' => __( 'Plan Currency Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .plan-price .curency' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_pricing_table_plan_currency_typography',
				'label' => __( 'Plan Currency Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-elementor-pricing-table-widget .plan-price .curency',
			]
        );
		$this->add_control(
			'divider3',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_price_color',
			[
				'label' => __( 'Plan Price Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .plan-price .price-number' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_pricing_table_plan_price_typography',
				'label' => __( 'Plan Price Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-elementor-pricing-table-widget .plan-price .price-number',
			]
        );
		$this->add_control(
			'divider4',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_duration_color',
			[
				'label' => __( 'Plan Duration Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .plan-price .plan-period' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_pricing_table_plan_duration_typography',
				'label' => __( 'Plan Duration Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-elementor-pricing-table-widget .plan-price .plan-period',
			]
        );
		$this->add_control(
			'divider5',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_enable_features_icon_color',
			[
				'label' => __( 'Plan Enable Features Icon Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget ul li.true:before' => 'color: {{VALUE}};',
				],
			]
		);		
		$this->add_control(
			'travail_pricing_table_plan_enable_features_color',
			[
				'label' => __( 'Plan Enable Features Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget ul li.true' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_pricing_table_plan_enable_features_typography',
				'label' => __( 'Plan Enable Features Text Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-elementor-pricing-table-widget ul li.true',
			]
        );
		$this->add_control(
			'divider6',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_disable_features_icon_color',
			[
				'label' => __( 'Plan Disable Features Icon Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget ul li.false:before' => 'color: {{VALUE}};',
				],
			]
		);		
		$this->add_control(
			'travail_pricing_table_plan_disable_features_color',
			[
				'label' => __( 'Plan Disable Features Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget ul li.false' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_pricing_table_plan_disable_features_typography',
				'label' => __( 'Plan Disable Features Text Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-elementor-pricing-table-widget ul li.false',
			]
        );
		$this->add_control(
			'divider7',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);        
		$this->add_control(
			'travail_pricing_table_plan_button_text_color',
			[
				'label' => __( 'Plan Button Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .button-secondary' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'travail_pricing_table_plan_button_bg',
				'label' => __( 'Plan Button Background', 'travail-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .travail-elementor-pricing-table-widget .button-secondary',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->add_control(
			'travail_pricing_table_plan_button_hover_color',
			[
				'label' => __( 'Plan Button Hover Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .button-secondary:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'travail_pricing_table_plan_button_background_hover',
				'label' => __( 'Plan Button Hover Background', 'travail-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .travail-elementor-pricing-table-widget .button-secondary:hover',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);        		        		       		        		        		        								
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_pricing_table_plan_button_typography',
				'label' => __( 'Plan Button Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-elementor-pricing-table-widget .button-secondary',
			]
        );
		$this->add_control(
			'divider8',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_header_overlay_color',
			[
				'label' => __( 'Plan Header Overlay Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .overlay' => 'background: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'travail_pricing_table_plan_body_overlay_color',
			[
				'label' => __( 'Plan Body Overlay Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-pricing-table-widget .content-overlay' => 'background: {{VALUE}};',
				],
			]
		);				       						
        $this->end_controls_section();			
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$travail_pricing_table_plan_name = $settings['travail_pricing_table_plan_name'];
		$travail_pricing_table_plan_currency = $settings['travail_pricing_table_plan_currency'];
		$travail_pricing_table_plan_price = $settings['travail_pricing_table_plan_price'];
		$travail_pricing_table_plan_duration = $settings['travail_pricing_table_plan_duration'];
		$travail_pricing_table_plan_enable_features = $settings['travail_pricing_table_plan_enable_features'];
		$travail_pricing_table_plan_disable_features = $settings['travail_pricing_table_plan_disable_features'];
		$travail_pricing_table_plan_btn_name = $settings['travail_pricing_table_plan_btn_name'];
		$travail_pricing_table_plan_btn_url = $settings['travail_pricing_table_plan_btn_url']['url'];
		$travail_pricing_table_plan_card_icon = $settings['travail_pricing_table_plan_card_icon']['value'];
		$travail_pricing_table_plan_header_bg_image = $settings['travail_pricing_table_plan_header_bg_image']['url'];
		$travail_pricing_table_plan_body_bg_image = $settings['travail_pricing_table_plan_body_bg_image']['url'];
	?>

	<div class="travail-elementor-pricing-table-widget">

		<?php echo do_shortcode('[travail_pricing_table 
			plan_name="'.$travail_pricing_table_plan_name.'" 
			plan_currency="'.$travail_pricing_table_plan_currency.'" 
			plan_price="'.$travail_pricing_table_plan_price.'" 
			plan_duration="'.$travail_pricing_table_plan_duration.'" 
			plan_header_bg_image="'.$travail_pricing_table_plan_header_bg_image.'" 
			plan_body_bg_image="'.$travail_pricing_table_plan_body_bg_image.'" 
			plan_card_icon="'.$travail_pricing_table_plan_card_icon.'" 
			plan_enable_features="'.$travail_pricing_table_plan_enable_features.'"
			plan_disable_features="'.$travail_pricing_table_plan_disable_features.'"
			plan_btn_name="'.$travail_pricing_table_plan_btn_name.'" 
			plan_btn_url="'.$travail_pricing_table_plan_btn_url.'"]'
			); 
        ?>
	</div>

	<?php
	}
}
