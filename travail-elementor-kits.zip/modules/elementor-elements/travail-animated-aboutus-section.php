<?php
namespace Travail\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class TravailAnimatedAboutSecWidget extends Widget_Base {

	public function get_name() {
		return 'travail-animated-aboutus-widget';
	}

	public function get_title() {
		return __( 'Travail Animated About Us Section', 'travail-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-columns';
	}

	public function get_categories() {
		return [ 'travail-elements' ];
	}
	/**
	 * Get button sizes.
	 *
	 * Retrieve an array of button sizes for the button widget.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @return array An array containing button sizes.
	 */
	public static function get_button_sizes() {
		return [
			'xs' => __( 'Extra Small', 'elementor' ),
			'sm' => __( 'Small', 'elementor' ),
			'md' => __( 'Medium', 'elementor' ),
			'lg' => __( 'Large', 'elementor' ),
			'xl' => __( 'Extra Large', 'elementor' ),
		];
	}
	/**
	 * Render button text.
	 *
	 * Render button widget text.
	 *
	 * @since 1.5.0
	 * @access protected
	 */
	protected function render_text() {
		$settings = $this->get_settings_for_display();

		$this->add_render_attribute( [
			'content-wrapper' => [
				'class' => 'elementor-button-content-wrapper',
			],
			'travail_button_text' => [
				'class' => 'elementor-button-text',
			],
		] );

		$this->add_inline_editing_attributes( 'travail_button_text', 'none' );
		?>
		<span <?php echo $this->get_render_attribute_string( 'content-wrapper' ); ?>>
			<span <?php echo $this->get_render_attribute_string( 'travail_button_text' ); ?>><?php echo $settings['travail_button_text']; ?></span>
		</span>
		<?php
	}
	protected function _register_controls() {
		$this->start_controls_section(
			'travail_aboutus_section_title',
			[
				'label' => __( 'Travail Title Settings', 'travail-elementor-kits' ),
			]
		);

		$this->add_control(
			'travail_aboutus_section_title_text',
			[
				'label' => __( 'Title', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your title', 'travail-elementor-kits' ),
				'default' => __( 'ABOUT EVENT', 'travail-elementor-kits' ),
			]
		);

		$this->add_responsive_control(
			'travail_aboutus_align',
			[
				'label' => __( 'Alignment', 'travail-elementor-kits' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} h4' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'travail_aboutus_title_bg_color',
				'label' => __( 'Title Gradient Color', 'travail-elementor-kits' ),
				'description' => __( 'Title Gradient Color and Solid Color', 'travail-elementor-kits' ),
				'types' => ['gradient' ],
				'selector' => '{{WRAPPER}} h4',
			]
		);		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_aboutus_typography',
				'label' => __( 'Title Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} h4',
			]
		);

		$this->add_responsive_control(
			'travail_aboutus_title_margin',
			[
				'label' => __( 'Title Margin', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'travail_aboutus_title_padding',
			[
				'label' => __( 'Title Padding', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);		
        $this->end_controls_section();

/***********************
Subtitle Settings
*************************/

		$this->start_controls_section(
			'travail_aboutus_section_subtitle',
			[
				'label' => __( 'Travail Sub-Title Settings', 'travail-elementor-kits' ),
			]
		);

		$this->add_control(
			'travail_aboutus_section_subtitle_text',
			[
				'label' => __( 'Sub-Title', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your sub-title', 'travail-elementor-kits' ),
				'default' => __( 'Welcome to the Largest Business Conference', 'travail-elementor-kits' ),
			]
		);

		$this->add_responsive_control(
			'travail_aboutus_subtitle_align',
			[
				'label' => __( 'Alignment', 'travail-elementor-kits' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} h1' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'travail_aboutus_subtitle_color',
			[
				'label' => __( 'Sub-Title Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} h1' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'travail_aboutus_subtitle_bg_color',
			[
				'label' => __( 'Sub-Title Background Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} h1' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_aboutus_subtitle_typography',
				'label' => __( 'Sub-Title Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} h4',
			]
		);
		$this->add_responsive_control(
			'travail_aboutus_subtitle_margin',
			[
				'label' => __( 'Sub-Title Margin', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'travail_aboutus_subtitle_padding',
			[
				'label' => __( 'Sub-Title Padding', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);	
        $this->end_controls_section();


/***********************
Description Settings
*************************/
		$this->start_controls_section(
			'travail_aboutus_section_desc',
			[
				'label' => __( 'Travail Description Settings', 'travail-elementor-kits' ),
			]
		);

		$this->add_control(
			'travail_aboutus_section_desc_text',
			[
				'label' => __( 'Description', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your Description', 'travail-elementor-kits' ),
				'default' => __( 'Dolor sit amet consectetur elit sed do eiusmod tempor incd idunt labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip exea commodo consequat.', 'travail-elementor-kits' ),
			]
		);

		$this->add_responsive_control(
			'travail_aboutus_desc_align',
			[
				'label' => __( 'Alignment', 'travail-elementor-kits' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'travail-elementor-kits' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} p' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'travail_aboutus_desc_color',
			[
				'label' => __( 'Description Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} p' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'travail_aboutus_desc_bg_color',
			[
				'label' => __( 'Description Background Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} p' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_aboutus_desc_typography',
				'label' => __( 'Description Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} p',
			]
		);
		$this->add_responsive_control(
			'travail_aboutus_desc_margin',
			[
				'label' => __( 'Description Margin', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'travail_aboutus_desc_padding',
			[
				'label' => __( 'Description Padding', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);	
        $this->end_controls_section();

/***********************
List Items Settings
*************************/
		$this->start_controls_section(
			'travail_aboutus_section_list_items',
			[
				'label' => __( 'Travail List Items Settings', 'travail-elementor-kits' ),
			]
		);
		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'text',
			[
				'label' => __( 'Text', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => __( 'List Item', 'travail-elementor-kits' ),
				'default' => __( 'List Item', 'travail-elementor-kits' ),
				'dynamic' => [
					'active' => true,
				],
			]
		);
		$repeater->add_control(
			'selected_icon',
			[
				'label' => __( 'Icon', 'travail-elementor-kits' ),
				'type' => Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-check',
					'library' => 'fa-solid',
				],
				'fa4compatibility' => 'icon',
			]
		);		
		$this->add_control(
			'icon_list',
			[
				'label' => __( 'Items', 'elementor' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'text' => __( 'Multiple Announcements during the event.', 'elementor' ),
						'selected_icon' => [
							'value' => 'fas fa-check-circle',
							'library' => 'fa-solid',
						],
					],
					[
						'text' => __( 'Logo & company details on the WordCamp.', 'elementor' ),
						'selected_icon' => [
							'value' => 'fas fa-check-circle',
							'library' => 'fa-solid',
						],
					],
					[
						'text' => __( 'Dedicated blog post thanking each Gold.', 'elementor' ),
						'selected_icon' => [
							'value' => 'fas fa-check-circle',
							'library' => 'fa-solid',
						],
					],
				],
				'title_field' => '{{{ elementor.helpers.renderIcon( this, selected_icon, {}, "i", "panel" ) || \'<i class="{{ icon }}" aria-hidden="true"></i>\' }}} {{{ text }}}',
			]
		);
		$this->add_responsive_control(
			'space_between',
			[
				'label' => __( 'Space Between Items', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-icon-list-items:not(.elementor-inline-items) .elementor-icon-list-item:not(:last-child)' => 'padding-bottom: calc({{SIZE}}{{UNIT}}/2)',
					'{{WRAPPER}} .elementor-icon-list-items:not(.elementor-inline-items) .elementor-icon-list-item:not(:first-child)' => 'margin-top: calc({{SIZE}}{{UNIT}}/2)',
					'{{WRAPPER}} .elementor-icon-list-items.elementor-inline-items .elementor-icon-list-item' => 'margin-right: calc({{SIZE}}{{UNIT}}/2); margin-left: calc({{SIZE}}{{UNIT}}/2)',
					'{{WRAPPER}} .elementor-icon-list-items.elementor-inline-items' => 'margin-right: calc(-{{SIZE}}{{UNIT}}/2); margin-left: calc(-{{SIZE}}{{UNIT}}/2)',
					'body.rtl {{WRAPPER}} .elementor-icon-list-items.elementor-inline-items .elementor-icon-list-item:after' => 'left: calc(-{{SIZE}}{{UNIT}}/2)',
					'body:not(.rtl) {{WRAPPER}} .elementor-icon-list-items.elementor-inline-items .elementor-icon-list-item:after' => 'right: calc(-{{SIZE}}{{UNIT}}/2)',
				],
			]
		);
		$this->add_responsive_control(
			'icon_align',
			[
				'label' => __( 'List Alignment', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'eicon-h-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'eicon-h-align-right',
					],
				],
				'prefix_class' => 'elementor%s-align-',
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label' => __( 'Icon Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .elementor-icon-list-icon i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .elementor-icon-list-icon svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'icon_color_hover',
			[
				'label' => __( 'Icon Hover Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .elementor-icon-list-item:hover .elementor-icon-list-icon i' => 'color: {{VALUE}};',
					'{{WRAPPER}} .elementor-icon-list-item:hover .elementor-icon-list-icon svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => __( 'Icon Size', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 14,
				],
				'range' => [
					'px' => [
						'min' => 6,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-icon-list-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .elementor-icon-list-icon svg' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_self_align',
			[
				'label' => __( 'Icon Alignment', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'eicon-h-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'eicon-h-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .elementor-icon-list-icon' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_color',
			[
				'label' => __( 'List Text Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .elementor-icon-list-text' => 'color: {{VALUE}};',
				],
				
			]
		);

		$this->add_control(
			'text_color_hover',
			[
				'label' => __( 'List Text Hover Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .elementor-icon-list-item:hover .elementor-icon-list-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'text_indent',
			[
				'label' => __( 'List Text Indent', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-icon-list-text' => is_rtl() ? 'padding-right: {{SIZE}}{{UNIT}};' : 'padding-left: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'icon_typography',
				'label' => __( 'List Typography', 'elementor' ),
				'selector' => '{{WRAPPER}} .elementor-icon-list-item',
				'scheme' => Typography::TYPOGRAPHY_3,
			]
		);

		$this->add_control(
			'travail_aboutus_list_bg_color',
			[
				'label' => __( 'List Background Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'travail_aboutus_list_margin',
			[
				'label' => __( 'List Margin', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} ul' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'travail_aboutus_list_padding',
			[
				'label' => __( 'List Padding', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} ul' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

/******************************
Button Settings
******************************/
		$this->start_controls_section(
			'travail_button_settings',
			[
				'label' => __( 'Travail Button Settings', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'travail_button_text',
			[
				'label' => __( 'Button Label', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => 'Register Now'
			]
		);
		$this->add_control(
			'travail_button_link',
			[
				'label' => __( 'Button Link', 'travail-elementor-kits' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'travail-elementor-kits' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->add_control(
			'travail_button_size',
			[
				'label' => __( 'Size', 'travail-elementor-kits' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'sm',
				'options' => self::get_button_sizes(),
				'style_transfer' => true,
			]
		);

		$this->add_control(
			'travail_button_css_id',
			[
				'label' => __( 'Button ID', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'default' => '',
				'title' => __( 'Add your custom id WITHOUT the Pound key. e.g: my-id', 'travail-elementor-kits' ),
				'description' => __( 'Please make sure the ID is unique and not used elsewhere on the page this form is displayed. This field allows <code>A-z 0-9</code> & underscore chars without spaces.', 'travail-elementor-kits' ),
				'separator' => 'before',

			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .elementor-button',
			]
		);
		$this->add_control(
			'travail_button_text_color',
			[
				'label' => __( 'Button Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .elementor-button' => 'fill: {{VALUE}}; color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'travail_button_background',
				'label' => __( 'Button Background', 'travail-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .elementor-button',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'global' => [
							'default' => Global_Colors::COLOR_ACCENT,
						],
					],
				],
			]
		);

		$this->add_control(
			'travail_button_hover_color',
			[
				'label' => __( 'Button Hover Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-button:hover, {{WRAPPER}} .elementor-button:focus' => 'color: {{VALUE}};',
					'{{WRAPPER}} .elementor-button:hover svg, {{WRAPPER}} .elementor-button:focus svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'travail_button_background_hover',
				'label' => __( 'Button Hover Background', 'travail-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .elementor-button:hover, {{WRAPPER}} .elementor-button:focus',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->add_control(
			'travail_button_hover_border_color',
			[
				'label' => __( 'Button Hover Border Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [
					'border_border!' => '',
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-button:hover, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'travail_button_hover_animation',
			[
				'label' => __( 'Button Hover Animation', 'travail-elementor-kits' ),
				'type' => Controls_Manager::HOVER_ANIMATION,
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'travail_button_border',
				'selector' => '{{WRAPPER}} .elementor-button',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'travail_button_border_radius',
			[
				'label' => __( 'Border Radius', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'travail_button_margin',
			[
				'label' => __( 'Button Margin', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'travail_button_padding',
			[
				'label' => __( 'Button Padding', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%', 'rem' ],
				'selectors' => [
					'{{WRAPPER}} .elementor-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);																	
		$this->end_controls_section();

/***********************
Round Image Settings
*************************/
		$this->start_controls_section(
			'travail_round_image_settings',
			[
				'label' => __( 'Travail Round Image Settings', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'travail_round_image',
			[
				'label' => __( 'Choose Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => TRAVAIL_ELEMENTOR_KITS_ASSETS . 'images/about-img-1.jpg',
				],
			]
		);

		$this->add_control(
			'travail_bg_animation_image',
			[
				'label' => __( 'Choose Background Animation Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => TRAVAIL_ELEMENTOR_KITS_ASSETS . 'images/shape-2.png',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'travail_round_image_border',
				'label' => __( 'Border', 'travail-elementor-kits' ),
				'selector' => '{{WRAPPER}} .travail-elementor-round-image-widget img',
			]
		);
	    $this->add_control(
	    	'travail_round_image_border_radius',
	    	 [
	    	 	'label' => __('Border Radius', 'travail-elementor-kits'), 
	    	 	'type' => Controls_Manager::DIMENSIONS, 
	    	 	'size_units' => ['px', '%'], 
	    	 	'selectors' => [
	    	 		'{{WRAPPER}} img ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	    	 	]
	    	]
	    );
        $this->add_group_control(
        	\Elementor\Group_Control_Box_Shadow::get_type(), 
        	[
        		'name' => 'travail_round_image_box_shadow', 
        		'selector' => '{{WRAPPER}}  img',
        	]
        );

		$this->add_control(
			'travail_round_image_width',
			[
				'label' => __( 'Image Size', 'travail-elementor-kits' ),
				'description' => __( 'Example: 100px or 50%', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => '400px',
	    	 	'selectors' => [
	    	 		'{{WRAPPER}} img ' => 'width: {{VALUE}}',
	    	 	]
			]
		);

		$this->add_control(
			'travail_animated_image_rotatation_start',
			[
				'label' => __( 'Animated image Rotatation Start From Degree', 'travail-elementor-kits' ),
				'description' => __( 'Example: 0deg', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => '0deg'
			]
		);
		$this->add_control(
			'travail_animated_image_rotatation_end',
			[
				'label' => __( 'Animated image Rotatation End To Degree', 'travail-elementor-kits' ),
				'description' => __( 'Example: 5deg or -5deg', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => '5deg'
			]
		);
        $this->end_controls_section();

/******************************
Background Animation Settings
******************************/
		$this->start_controls_section(
			'travail_bg_animation_settings',
			[
				'label' => __( 'Travail Background Animation Settings', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'travail_bg_animation_left_img',
			[
				'label' => __( 'Choose Left Side Background Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => TRAVAIL_ELEMENTOR_KITS_ASSETS . 'images/icon-circle-1.png',
				],
			]
		);
		$this->add_control(
			'travail_bg_animation_center_img',
			[
				'label' => __( 'Choose Center Background Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => TRAVAIL_ELEMENTOR_KITS_ASSETS . 'images/icon-dots.png',
				],
			]
		);
		$this->add_control(
			'travail_bg_animation_right_img',
			[
				'label' => __( 'Choose Right Side Background Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => TRAVAIL_ELEMENTOR_KITS_ASSETS . 'images/circle-blue.png',
				],
			]
		);						
		$this->add_control(
			'travail_bg_animation_desktop_switch',
			[
				'label' 		=> __( 'On/Off Background Animation in Desktop', 'travail-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'on',				
				'options' 		=> [
					'on' 		=> __( 'On', 'travail-elementor-kits' ),
					'off' 		=> __( 'Off', 'travail-elementor-kits' ),
				],
			]
		);
		$this->add_control(
			'travail_bg_animation_mobile_switch',
			[
				'label' 		=> __( 'On/Off Background Animation in Mobile', 'travail-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'off',				
				'options' 		=> [
					'on' 		=> __( 'On', 'travail-elementor-kits' ),
					'off' 		=> __( 'Off', 'travail-elementor-kits' ),
				],
			]
		);
		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$travail_round_image = $settings['travail_round_image']['url'];
		$travail_bg_animation_image = $settings['travail_bg_animation_image']['url'];
		$travail_animated_image_rotatation_start = $settings['travail_animated_image_rotatation_start'];
		$travail_animated_image_rotatation_end = $settings['travail_animated_image_rotatation_end'];

		$travail_aboutus_section_title_text = $settings['travail_aboutus_section_title_text'];
		$travail_aboutus_align = $settings['travail_aboutus_align'];

		$travail_aboutus_section_subtitle_text = $settings['travail_aboutus_section_subtitle_text'];
		$travail_aboutus_subtitle_align = $settings['travail_aboutus_subtitle_align'];
		$travail_aboutus_subtitle_color = $settings['travail_aboutus_subtitle_color'];

		$travail_aboutus_section_desc_text = $settings['travail_aboutus_section_desc_text'];
		$travail_aboutus_desc_align = $settings['travail_aboutus_desc_align'];
		$travail_aboutus_desc_color = $settings['travail_aboutus_desc_color'];

		$travail_bg_animation_desktop_switch = $settings['travail_bg_animation_desktop_switch'];
		$travail_bg_animation_mobile_switch = $settings['travail_bg_animation_mobile_switch'];
		$travail_bg_animation_left_img = $settings['travail_bg_animation_left_img']['url'];
		$travail_bg_animation_center_img = $settings['travail_bg_animation_center_img']['url'];
		$travail_bg_animation_right_img = $settings['travail_bg_animation_right_img']['url'];
		
		$travail_button_text = $settings['travail_button_text'];

		$fallback_defaults = [
			'fas fa-check-circle',
			'fas fa-check-circle',
			'fas fa-check-circle',
		];

		$this->add_render_attribute( 'icon_list', 'class', 'elementor-icon-list-items' );
		$this->add_render_attribute( 'list_item', 'class', 'elementor-icon-list-item' );

		if($travail_bg_animation_left_img){
			echo"
			<style>
            {{WRAPPER}} .travail-elementor-animated-aboutus-widget .icon-circle-1{
            	background-image:url(".$travail_bg_animation_left_img.");
            }
			</style>
			";
		}
		if($travail_bg_animation_center_img){
			echo"
			<style>
            {{WRAPPER}} .travail-elementor-animated-aboutus-widget .icon-dots{
            	background-image:url(".$travail_bg_animation_center_img.");
            }
			</style>
			";
		}
		if($travail_bg_animation_right_img){
			echo"
			<style>
            {{WRAPPER}} .travail-elementor-animated-aboutus-widget .icon-circle-blue{
            	background-image:url(".$travail_bg_animation_right_img.");
            }
			</style>
			";
		}				
		if($travail_bg_animation_image){
			echo "
			<style>
            {{WRAPPER}} .travail-elementor-animated-aboutus-widget .travail-image-wrapper:before{background-image:url(".$travail_bg_animation_image.");}
			</style>
			";
		}
		if($travail_animated_image_rotatation_start && $travail_animated_image_rotatation_end){
			echo "
			<style>
				@keyframes dizzling{
				    0%{
				        -webkit-transform: rotate(".$travail_animated_image_rotatation_start.");
				        -moz-transform: rotate(".$travail_animated_image_rotatation_start.");
				        -ms-transform: rotate(".$travail_animated_image_rotatation_start.");
				        -o-transform: rotate(".$travail_animated_image_rotatation_start.");
				        transform: rotate(".$travail_animated_image_rotatation_start.");
				    }
				    50%{
				        -webkit-transform: rotate(".$travail_animated_image_rotatation_end.");
				        -moz-transform: rotate(".$travail_animated_image_rotatation_end.");
				        -ms-transform: rotate(".$travail_animated_image_rotatation_end.");
				        -o-transform: rotate(".$travail_animated_image_rotatation_end.");
				        transform: rotate(".$travail_animated_image_rotatation_end.");
				    }
				    100%{
				        -webkit-transform: rotate(".$travail_animated_image_rotatation_start."0);
				        -moz-transform: rotate(".$travail_animated_image_rotatation_start.");
				        -ms-transform: rotate(".$travail_animated_image_rotatation_start.");
				        -o-transform: rotate(".$travail_animated_image_rotatation_start.");
				        transform: rotate(".$travail_animated_image_rotatation_start.");
				    }
				}            
			</style>
			";
		}
		if($travail_bg_animation_desktop_switch == "off"){
			echo "
            <style>
				@media only screen and (min-width: 768px) {
				 {{WRAPPER}} .anim-icons{display:none;}
				 {{WRAPPER}} {paddin-top:100px;padding-bottom:100px}
				}
            </style>
			";
		}
		if($travail_bg_animation_mobile_switch == "off"){
			echo "
            <style>
				@media only screen and (max-width: 767px) {
				 {{WRAPPER}} .anim-icons{display:none;}
				}
            </style>
			";
		}
		$this->add_render_attribute( 'btn_wrapper', 'class', 'elementor-button-wrapper' );

		if ( ! empty( $settings['travail_button_link']['url'] ) ) {
			$this->add_link_attributes( 'button', $settings['travail_button_link'] );
			$this->add_render_attribute( 'button', 'class', 'elementor-button-link' );
		}

		$this->add_render_attribute( 'button', 'class', 'elementor-button' );
		$this->add_render_attribute( 'button', 'role', 'button' );

		if ( ! empty( $settings['travail_button_css_id'] ) ) {
			$this->add_render_attribute( 'button', 'id', $settings['travail_button_css_id'] );
		}

		if ( ! empty( $settings['travail_button_size'] ) ) {
			$this->add_render_attribute( 'button', 'class', 'elementor-size-' . $settings['travail_button_size'] );
		}

		if ( $settings['travail_button_hover_animation'] ) {
			$this->add_render_attribute( 'button', 'class', 'elementor-animation-' . $settings['travail_button_hover_animation'] );
		}				
	?>
	<div class="travail-elementor-animated-aboutus-widget">
		<div class="anim-icons full-width">
		    <span class="icon icon-circle-blue wow fadeIn" style="visibility: visible; animation-name: fa-spin;"></span>
		    <span class="icon icon-dots wow fadeInleft" style="visibility: visible;"></span>
		    <span class="icon icon-circle-1 wow zoomIn" style="visibility: visible; animation-name: zoomIn;"></span>
		</div>		
		<div class="container-fluid">
			<div class="row align-items-center">
				<div class="col-md-6">
					<?php if($travail_aboutus_section_title_text) { ?>
					<h4><?php echo $travail_aboutus_section_title_text; ?></h4>
				    <?php } ?>
				    <?php if($travail_aboutus_section_subtitle_text) { ?>
					<h1><?php echo $travail_aboutus_section_subtitle_text; ?></h1>
					<?php } ?>
					<?php if($travail_aboutus_section_desc_text) { ?>
					<p><?php echo $travail_aboutus_section_desc_text; ?></p>
					<?php } ?>
					<ul <?php echo $this->get_render_attribute_string( 'icon_list' ); ?>>
						<?php
						foreach ( $settings['icon_list'] as $index => $item ) :
							$repeater_setting_key = $this->get_repeater_setting_key( 'text', 'icon_list', $index );

							$this->add_render_attribute( $repeater_setting_key, 'class', 'elementor-icon-list-text' );

							$this->add_inline_editing_attributes( $repeater_setting_key );
							$migration_allowed = \Elementor\Icons_Manager::is_migration_allowed();
							?>
							<li <?php echo $this->get_render_attribute_string( 'list_item' ); ?>>
								<?php
								// add old default
								if ( ! isset( $item['icon'] ) && ! $migration_allowed ) {
									$item['icon'] = isset( $fallback_defaults[ $index ] ) ? $fallback_defaults[ $index ] : 'fa fa-check';
								}

								$migrated = isset( $item['__fa4_migrated']['selected_icon'] );
								$is_new = ! isset( $item['icon'] ) && $migration_allowed;
								if ( ! empty( $item['icon'] ) || ( ! empty( $item['selected_icon']['value'] ) && $is_new ) ) :
									?>
									<span class="elementor-icon-list-icon">
										<?php
										if ( $is_new || $migrated ) {
											\Elementor\Icons_Manager::render_icon( $item['selected_icon'], [ 'aria-hidden' => 'true' ] );
										} else { ?>
												<i class="<?php echo esc_attr( $item['icon'] ); ?>" aria-hidden="true"></i>
										<?php } ?>
									</span>
								<?php endif; ?>
								<span <?php echo $this->get_render_attribute_string( $repeater_setting_key ); ?>><?php echo $item['text']; ?></span>
							</li>
							<?php
						endforeach;
						?>
					</ul>
					<?php if($travail_button_text) { ?>
					<div <?php echo $this->get_render_attribute_string( 'btn_wrapper' ); ?>>
						<a <?php echo $this->get_render_attribute_string( 'button' ); ?>>
							<?php $this->render_text(); ?>
						</a>
					</div>
					<?php } ?>					
				</div>
				<div class="col-md-6">
					<div class="travail-image-wrapper">
		                <img src="<?php echo esc_url($travail_round_image); ?>"/>
		            </div>
				</div>
			</div>	
	    </div>
	</div>
	<script>
		jQuery(document).ready(function(){
			jQuery(".travail-elementor-animated-aboutus-widget").parent().closest('section.elementor-section').addClass("o-hidden pt-100 pb-100");
		});
	</script>	
	<?php
}

}
