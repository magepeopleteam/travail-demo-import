<?php
namespace Travail\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class TravailContactFormWidget extends Widget_Base {

	public function get_name() {
		return 'travail-contact-form-widget';
	}

	public function get_title() {
		return __( 'Travail Contact Form', 'travail-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	public function get_categories() {
		return [ 'travail-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'travail_contact_form_settings',
			[
				'label' => __( 'Travail Contact Form Settings', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'travail_contact_form_subject',
			[
				'label' => __( 'Form Subject','travail-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'default' => 'New Entry: Contact Us',
			]
		);
		$this->add_control(
			'travail_contact_form_recipient_email',
			[
				'label' => __( 'Form Recipient Email','travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => get_option( 'admin_email' ),
			]
		);
		$this->add_control(
			'travail_contact_form_btn_label',
			[
				'label' => __( 'Form Button Label','travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Send Message',
			]
		);																			
        $this->end_controls_section();
        
		$this->start_controls_section(
			'travail_contact_form_style',
			[
				'label' => __( 'Travail Contact Form Style', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);				
		$this->add_control(
			'travail_contact_form_button_text_color',
			[
				'label' => __( 'Button Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-contact-form-widget #vek_cf_btn' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'travail_contact_form_button_bg',
				'label' => __( 'Button Background', 'travail-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .travail-elementor-contact-form-widget #vek_cf_btn',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->add_control(
			'travail_contact_form_button_hover_color',
			[
				'label' => __( 'Button Hover Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-contact-form-widget #vek_cf_btn:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'travail_contact_form_button_background_hover',
				'label' => __( 'Button Hover Background', 'travail-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .travail-elementor-contact-form-widget #vek_cf_btn:hover',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);        		        		       		        		        		        								
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_contact_form_button_typography',
				'label' => __( 'Button Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-elementor-contact-form-widget #vek_cf_btn',
			]
        );		
        $this->end_controls_section();		                
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$travail_contact_form_subject = $settings['travail_contact_form_subject'];
		$travail_contact_form_recipient_email = $settings['travail_contact_form_recipient_email'];
		$travail_contact_form_btn_label = $settings['travail_contact_form_btn_label'];
	?>

	<div class="travail-elementor-contact-form-widget">
    <?php echo do_shortcode('[travail_contact_form subject="'.$travail_contact_form_subject.'" recipient="'.$travail_contact_form_recipient_email.'" btn_label="'.$travail_contact_form_btn_label.'"]'); ?>
	</div>

	<?php
}

}
