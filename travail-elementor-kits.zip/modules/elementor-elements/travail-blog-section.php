<?php
namespace Travail\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class TravailBlogSectionWidget extends Widget_Base {

	public function get_name() {
		return 'travail-blog-section-widget';
	}

	public function get_title() {
		return __( 'Travail Blog', 'travail-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-posts-grid';
	}

	public function get_categories() {
		return [ 'travail-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'travail_blog_section_settings',
			[
				'label' => __( 'Travail Blog Section Settings', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'travail_blog_categories',
			[
				'label' => __( 'Choose Categories', 'travail-elementor-kits' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'default' => '0',
				'options' => vek_blog_get_categories(),			
				'separator' => 'none',
			]
		);
		$this->add_control(
			'travail_blog_item_show',
			[
				'label' => __( 'No. of Blog Post Show','travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'default' => __( '3', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_blog_excerpt_limit',
			[
				'label' => __( 'Post Description Word Limit','travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'default' => __( '15', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_blog_post_order',
			[
				'label' => __( 'Post Order', 'travail-elementor-kits' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => ['DESC' => 'Descending', 'ASC' => 'Ascending'],			
				'separator' => 'none',
			]
		);
		$this->add_control(
			'travail_blog_post_orderby',
			[
				'label' => __( 'Post Orderby', 'travail-elementor-kits' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => ['date' => 'Date', 'title' => 'Title', 'rand' => 'Random', 'ID' => 'ID', 'ID' => 'ID'],	
				'separator' => 'none',
			]
		);
		$this->add_control(
			'travail_blog_post_date_format',
			[
				'label' => __( 'Date Format', 'travail-elementor-kits' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => ['wp' => 'WordPress Default', 'style1' => 'Style-1'],			
				'separator' => 'none',
			]
		);																						
        $this->end_controls_section();
		$this->start_controls_section(
			'travail_blog_section_style',
			[
				'label' => __( 'Travail Blog Section Style', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'travail_blog_post_date_text_color',
			[
				'label' => __( 'Date Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-date' => 'color: {{VALUE}};',
				],
			]
        );
		$this->add_control(
			'travail_blog_post_date_bg',
			[
				'label' => __( 'Date Background', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-date' => 'background-color: {{VALUE}};',
				],
			]
        );
		$this->add_control(
			'travail_blog_post_date_hover_text_color',
			[
				'label' => __( 'Date Hover Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-date:hover' => 'color: {{VALUE}};',
				],
			]
        );        
		$this->add_control(
			'travail_blog_post_date_hover_bg',
			[
				'label' => __( 'Date Hover Background', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-date:hover' => 'background-color: {{VALUE}};',
				],
			]
        );
		$this->add_control(
			'divider1',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);        
		$this->add_control(
			'travail_blog_post_meta_icon_color',
			[
				'label' => __( 'Meta Box Icon Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-author-n-comments i' => 'color: {{VALUE}};',
				],
			]
        );        
		$this->add_control(
			'travail_blog_post_meta_text_color',
			[
				'label' => __( 'Meta Box Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-author-n-comments span' => 'color: {{VALUE}};',
					'{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-author-n-comments span a' => 'color: {{VALUE}};',
				],
			]
        );        
		$this->add_control(
			'travail_blog_post_meta_bg',
			[
				'label' => __( 'Meta Box Background', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-author-n-comments' => 'background-color: {{VALUE}};',
				],
			]
        );
		$this->add_control(
			'divider2',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);        
		$this->add_control(
			'travail_blog_post_title_color',
			[
				'label' => __( 'Post Title Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-title' => 'color: {{VALUE}};',
				],
			]
        );
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_blog_post_title_typography',
				'label' => __( 'Post Title Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-title',
			]
        );
		$this->add_control(
			'divider3',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);        
		$this->add_control(
			'travail_blog_post_desc_color',
			[
				'label' => __( 'Post Description Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-excerpt' => 'color: {{VALUE}};',
				],
			]
        );
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_blog_post_desc_typography',
				'label' => __( 'Post Description Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-excerpt',
			]
        );
		$this->add_control(
			'divider4',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control(
			'travail_blog_post_content_bg',
			[
				'label' => __( 'Post Content Background Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-blog-section .blog-post-item-1 .post-content' => 'background-color: {{VALUE}};',
				],
			]
        );		                                       
		$this->end_controls_section();			
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$travail_blog_categories = $settings['travail_blog_categories'];
		$travail_blog_item_show = $settings['travail_blog_item_show'];
		$travail_blog_excerpt_limit = $settings['travail_blog_excerpt_limit'];
		$travail_blog_post_order = $settings['travail_blog_post_order'];
		$travail_blog_post_orderby = $settings['travail_blog_post_orderby'];
		$travail_blog_post_date_format = $settings['travail_blog_post_date_format'];
		if($travail_blog_categories){
			$cat_string = implode(", ", $travail_blog_categories);			
		} else {
			$cat_string = '';
		}

	?>

	<div class="travail-elementor-blog-section-widget">

		<?php echo do_shortcode('[travail_blog category="'.$cat_string.'" num_post="'.$travail_blog_item_show.'" word_limit="'.$travail_blog_excerpt_limit.'" order="'.$travail_blog_post_order.'" orderby="'.$travail_blog_post_orderby.'" date_format="'.$travail_blog_post_date_format.'" ]'); 
        ?>
	</div>

	<?php
	}
}
