<?php
namespace Travail\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;
use Elementor\Group_Control_Background;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Group_Control_Border;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class TravailSpeakerBoxWidget extends Widget_Base {

	public function get_name() {
		return 'travail-speaker-box-widget';
	}

	public function get_title() {
		return __( 'Travail Event Speaker Box', 'travail-elementor-kits' );
	}

	public function get_icon() {
		return ' eicon-image-box';
	}

	public function get_categories() {
		return [ 'travail-elements' ];
	}

	protected function _register_controls() {

/***********************
Travail Speaker Settings
***********************/

		$this->start_controls_section(
			'travail_speaker_box_settings',
			[
				'label' => __( 'Travail Speaker Settings', 'travail-elementor-kits' ),
			]
		);

		$this->add_control(
			'travail_speaker_name',
			[
				'label' => __( 'Speaker Name', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter speaker name', 'travail-elementor-kits' ),
				'default' => __( 'Dale Marke', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_speaker_designation',
			[
				'label' => __( 'Speaker Designation', 'travail-elementor-kits' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter speaker designation', 'travail-elementor-kits' ),
				'default' => __( 'Event Manager', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_speaker_image',
			[
				'label' => __( 'Speaker Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => TRAVAIL_ELEMENTOR_KITS_ASSETS . 'images/speaker-6.jpg',
				],
			]
		);
		$this->add_control(
			'travail_speaker_facebook_link',
			[
				'label' => __( 'Facebook Profile Link', 'travail-elementor-kits' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com/username', 'travail-elementor-kits' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'travail_speaker_twitter_link',
			[
				'label' => __( 'Twitter Profile Link', 'travail-elementor-kits' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com/username', 'travail-elementor-kits' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'travail_speaker_linkedin_link',
			[
				'label' => __( 'Linkedin Profile Link', 'travail-elementor-kits' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com/username', 'travail-elementor-kits' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'travail_speaker_instagram_link',
			[
				'label' => __( 'Instagram Profile Link', 'travail-elementor-kits' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com/username', 'travail-elementor-kits' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'travail_speaker_details_link',
			[
				'label' => __( 'Speaker Details Page Link', 'travail-elementor-kits' ),
				'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'travail-elementor-kits' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);												
        $this->end_controls_section();

/******************************
Travail Speaker Style Settings
******************************/

		$this->start_controls_section(
			'travail_speaker_box_style_settings',
			[
				'label' => __( 'Travail Speaker Box Style', 'travail-elementor-kits' ),
			]
		);
		$this->add_control(
			'travail_speaker_name_color',
			[
				'label' => __( 'Speaker Name Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-speaker-box-widget .name a' => ' color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_speaker_name_typography',
				'label' => __( 'Speaker Name Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-elementor-speaker-box-widget .name',
			]
		);
		$this->add_control(
			'travail_speaker_designation_color',
			[
				'label' => __( 'Speaker Designation Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-speaker-box-widget .designation' => ' color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_speaker_designation_typography',
				'label' => __( 'Speaker Designation Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .travail-elementor-speaker-box-widget .designation',
			]
		);
		$this->add_control(
			'travail_speaker_box_social_icons_color',
			[
				'label' => __( 'Social Icons Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-speaker-box-widget .social-links li a i' => ' color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'travail_speaker_box_social_icons_bgcolor',
				'label' => __( 'Social Icons Background', 'travail-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .travail-elementor-speaker-box-widget .social-links li a i',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->add_control(
			'travail_speaker_box_social_icons_hover_color',
			[
				'label' => __( 'Social Icons Hover Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-speaker-box-widget .social-links li a:hover i' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'travail_speaker_box_social_icons_hover_bg',
				'label' => __( 'Social Icons Hover Background', 'travail-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .travail-elementor-speaker-box-widget .social-links li a:hover i',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);
		$this->add_control(
			'travail_speaker_box_hover_bg',
			[
				'label' => __( 'Speaker Box Hover Background', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-speaker-box-widget .speaker-block .info-box' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'travail_speaker_box_border_radius',
			[
				'label' => __( 'Border Radius', 'travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-speaker-box-widget .speaker-block .inner-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_group_control(
        	\Elementor\Group_Control_Box_Shadow::get_type(), 
        	[
        		'name' => 'travail_speaker_box_shadow', 
        		'selector' => '{{WRAPPER}} .travail-elementor-speaker-box-widget  .speaker-block .inner-box',
        	]
        );
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'travail_speaker_box_border',
				'selector' => '{{WRAPPER}} .travail-elementor-speaker-box-widget .speaker-block .inner-box',
				'separator' => 'before',
			]
		);
        $this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$travail_speaker_name = $settings['travail_speaker_name'];
		$travail_speaker_designation = $settings['travail_speaker_designation'];
		$travail_speaker_facebook_link = $settings['travail_speaker_facebook_link']['url'];
		$travail_speaker_twitter_link = $settings['travail_speaker_twitter_link']['url'];
		$travail_speaker_linkedin_link = $settings['travail_speaker_linkedin_link']['url'];
		$travail_speaker_instagram_link = $settings['travail_speaker_instagram_link']['url'];
		$travail_speaker_details_link = $settings['travail_speaker_details_link']['url'];
		$travail_speaker_image = $settings['travail_speaker_image']['url'];
	?>

	<div class="travail-elementor-speaker-box-widget">
	<div class="speaker-block">
	   <div class="inner-box">
	      <div class="image-box">
	         <figure class="image"><a href="<?php echo esc_url($travail_speaker_details_link); ?>"><img src="<?php echo esc_url($travail_speaker_image); ?>" alt="<?php echo $travail_speaker_name; ?>"></a></figure>
	      </div>
	      <div class="info-box">
	         <div class="inner">
	         	<?php if($travail_speaker_name) { ?>
	            <h4 class="name"><a href="<?php echo esc_url($travail_speaker_details_link); ?>"><?php echo $travail_speaker_name; ?></a></h4>
	            <?php } ?>
	            <?php if($travail_speaker_designation) { ?>
	            <span class="designation"><?php echo $travail_speaker_designation; ?></span>
	            <?php } ?>
	            <ul class="social-links social-icon-colored">
	            <?php if($travail_speaker_facebook_link) { ?>
	               <li><a href="<?php echo esc_url($travail_speaker_facebook_link); ?>"><i class="fab fa-facebook-f"></i></a></li>
	            <?php } ?>
	            <?php if($travail_speaker_twitter_link) { ?>
	               <li><a href="<?php echo esc_url($travail_speaker_twitter_link); ?>"><i class="fab fa-twitter"></i></a></li>
	            <?php } ?>
	            <?php if($travail_speaker_linkedin_link) { ?>   
	               <li><a href="<?php echo esc_url($travail_speaker_linkedin_link); ?>"><i class="fab fa-linkedin-in"></i></a></li>
	            <?php } ?>
	            <?php if($travail_speaker_instagram_link) { ?>    
	               <li><a href="<?php echo esc_url($travail_speaker_instagram_link); ?>"><i class="fab fa-instagram"></i></a></li>
	            <?php } ?>   
	            </ul>
	         </div>
	      </div>
	   </div>
	</div>		
	</div>
	<?php
}

}
