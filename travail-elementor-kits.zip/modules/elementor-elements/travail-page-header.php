<?php
namespace Travail\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class TravailPageHeaderWidget extends Widget_Base {

	public function get_name() {
		return 'travail-page-header-widget';
	}

	public function get_title() {
		return __( 'Travail Page Header', 'travail-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-header';
	}

	public function get_categories() {
		return [ 'travail-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'travail_page_header_settings',
			[
				'label' => __( 'Travail Page Header Settings', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'travail_page_header_bg_image',
			[
				'label' => __( 'Background Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
			]
		);

		$this->add_control(
			'travail_page_header_bg_size',
			[
				'label' 		=> __( 'Background Size', 'travail-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'cover',				
				'options' 		=> [
					'cover' 		=> __( 'Cover', 'travail-elementor-kits' ),
					'contain' 		=> __( 'Contain', 'travail-elementor-kits' ),
				],
			]
		);

		$this->add_control(
			'travail_page_header_bg_position',
			[
				'label' 		=> __( 'Background Position', 'travail-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'center',				
				'options' 		=> [
					'top' 		=> __( 'Top', 'travail-elementor-kits' ),
					'center' 		=> __( 'Center', 'travail-elementor-kits' ),
					'bottom' 		=> __( 'Bottom', 'travail-elementor-kits' ),
					'left' 		=> __( 'Left', 'travail-elementor-kits' ),
					'right' 		=> __( 'Right', 'travail-elementor-kits' ),
				],
			]
		);

		$this->add_control(
			'travail_page_header_bg_repeat',
			[
				'label' 		=> __( 'Background Repeat', 'travail-elementor-kits' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'no-repeat',				
				'options' 		=> [
					'repeat' 		=> __( 'Repeat', 'travail-elementor-kits' ),
					'repeat-x' 		=> __( 'Repeat-x', 'travail-elementor-kits' ),
					'repeat-y' 		=> __( 'Repeat-y', 'travail-elementor-kits' ),
					'no-repeat' 		=> __( 'No-repeat', 'travail-elementor-kits' ),
				],
			]
		);

		$this->add_control(
			'travail_page_header_text_color',
			[
				'label' => __( 'Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bread-crumb h4, .bread-crumb h4 a, .bread-crumb i' => 'color: {{VALUE}};',
				],
			]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_page_header_text_typography',
				'label' => __( 'Text Typography', 'travail-elementor-kits' ),
				'scheme' => Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .bread-crumb h4, .bread-crumb h4 a',
			]
        );

        $this->end_controls_section();
	
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$travail_page_header_bg_image = $settings['travail_page_header_bg_image']['url'] ;
		$travail_page_header_bg_size = $settings['travail_page_header_bg_size'] ;
		$travail_page_header_bg_position = $settings['travail_page_header_bg_position'] ;
		$travail_page_header_bg_repeat = $settings['travail_page_header_bg_repeat'] ;
		if($travail_page_header_bg_image || $travail_page_header_bg_size || $travail_page_header_bg_position || $travail_page_header_bg_repeat){
			echo "
			<style>
			.page-top-banner {
			    background-image: url(".$travail_page_header_bg_image.");
			    background-size: ".$travail_page_header_bg_size.";
			    background-position: ".$travail_page_header_bg_position.";
			    background-repeat: ".$travail_page_header_bg_repeat.";
			}
			</style>
			";
		}
	?>
	<div class="travail-elementor-page-header-widget">
		<?php travail_page_header_function(); ?>
	</div>
	<?php
}

}
