<?php

namespace Travail;

class TravailElementor {
	
	private static $_instance = null;
	
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		
		return self::$_instance;
	}
	
	
	public function add_widget_categories( $elements_manager ) {
		
		$elements_manager->add_category(
			'travail-elements',
			[
				'title' => __( 'Travail Elements', 'travail-elementor-kits'),
				'icon'  => 'fa fa-plug',
			]
		);
		
	}
	
	private function include_widgets_files() {
		require_once( __DIR__ . '/travail-page-header.php' );		
		require_once( __DIR__ . '/travail-countdown.php' );		
		require_once( __DIR__ . '/travail-round-image.php' );		
		require_once( __DIR__ . '/travail-animated-aboutus-section.php' );		
		require_once( __DIR__ . '/travail-speaker-box.php' );		
		require_once( __DIR__ . '/travail-pricing-table.php' );		
		require_once( __DIR__ . '/travail-video-popup.php' );		
		require_once( __DIR__ . '/travail-blog-section.php' );		
		require_once( __DIR__ . '/travail-newsletter.php' );		
		require_once( __DIR__ . '/travail-contact-form.php' );		
	}
	
	public function register_widgets() {
		
		// Its is now safe to include Widgets files
		$this->include_widgets_files();
		
		// Register Widgets		
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TravailPageHeaderWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TravailCountdownWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TravailRoundImageWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TravailAnimatedAboutSecWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TravailSpeakerBoxWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TravailPricingTableWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TravailVideoPopupWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TravailBlogSectionWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TravailNewsletterWidget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\TravailContactFormWidget() );
	}
	
	public function __construct() {
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        if ( \is_plugin_active( 'elementor/elementor.php' ) ) {
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
		add_action( 'elementor/elements/categories_registered', [ $this, 'add_widget_categories' ] );
        }
	}
}


// Instantiate Plugin Class
TravailElementor::instance();
