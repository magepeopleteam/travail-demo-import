<?php
namespace Travail\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class TravailCountdownWidget extends Widget_Base {

	public function get_name() {
		return 'travail-countdown-widget';
	}

	public function get_title() {
		return __( 'Travail Countdown', 'travail-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-countdown';
	}

	public function get_categories() {
		return [ 'travail-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'travail_countdown_settings',
			[
				'label' => __( 'Travail Countdown Settings', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'divider1',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'travail_countdown_year',
			[
				'label' => __( 'Countdown End Year (YYYY)','travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '2022',
			]
		);

		$this->add_control(
			'divider2',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'travail_countdown_month',
			[
				'label' => __( 'Countdown End Month (MM)','travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '02',
			]
		);

		$this->add_control(
			'divider3',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'travail_countdown_date',
			[
				'label' => __( 'Countdown End Date (DD)','travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '25',
			]
		);

		$this->add_control(
			'divider4',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'travail_countdown_hour',
			[
				'label' => __( 'Countdown End Hour (HH)','travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '23',
			]
		);

		$this->add_control(
			'divider5',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'travail_countdown_minute',
			[
				'label' => __( 'Countdown End Minute (MM)','travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '59',
			]
		);

		$this->add_control(
			'divider6',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'travail_countdown_second',
			[
				'label' => __( 'Countdown End Second (SS)','travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '59',
			]
		);

		$this->add_control(
			'divider7',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'travail_countdown_end_text',
			[
				'label' => __( 'Countdown End Text','travail-elementor-kits' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Happy Event!',
			]
		);

        $this->end_controls_section();

		$this->start_controls_section(
			'travail_countdown_style_settings',
			[
				'label' => __( 'Travail Countdown Style Settings', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'travail_countdown_bgimage',
			[
				'label' => __( 'Countdown Background Image', 'travail-elementor-kits' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => '',
				],
			]
		);

		$this->add_control(
			'divider8',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'travail_countdown_bg_color',
			[
				'label' => __( 'Countdown Background Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-countdown-widget .travail-countdown .travail-count-wrapper' => 'background-color: {{VALUE}};',
				],
			]
        );

		$this->add_control(
			'divider9',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

		$this->add_control(
			'travail_countdown_text_color',
			[
				'label' => __( 'Countdown Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-countdown-widget .travail-countdown .travail-count-wrapper' => 'color: {{VALUE}};',
				],
			]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_countdown_number_typography',
				'label' => __( 'Countdown Number Typography', 'travail-elementor-kits' ),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .travail-elementor-countdown-widget .travail-countdown .travail-count-wrapper .number',
			]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_countdown_title_typography',
				'label' => __( 'Countdown Title Typography', 'travail-elementor-kits' ),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .travail-elementor-countdown-widget .travail-countdown .travail-count-wrapper .title',
			]
        );

		$this->add_control(
			'travail_countdown_wrapper_width',
			[
				'label' => __( 'Countdown Item Wrapper Width (px)','travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-countdown-widget .travail-countdown .travail-count-wrapper' => 'width: {{VALUE}}px;',
				],
			]
		);

		$this->add_control(
			'travail_countdown_wrapper_height',
			[
				'label' => __( 'Countdown Item Wrapper Height (px)','travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-countdown-widget .travail-countdown .travail-count-wrapper' => 'height: {{VALUE}}px;',
				],
			]
		);
		$this->add_control(
			'travail_countdown_wrapper_margin',
			[
				'label' => __( 'Countdown Item Wrapper Margin (px)','travail-elementor-kits' ),
				'type' => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-countdown-widget .travail-countdown .travail-count-wrapper' => 'margin: {{VALUE}}px;',
				],
			]
		);
		$this->add_control(
			'travail_countdown_wrapper_padding',
			[
				'label' => __( 'Countdown Item Wrapper Padding','travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px'],
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-countdown-widget .travail-countdown .travail-count-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'travail_countdown_wrapper_border_radius',
			[
				'label' => __( 'Countdown Item Wrapper Border Radius','travail-elementor-kits' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => ['px', '%'],
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-countdown-widget .travail-countdown .travail-count-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);		
        $this->end_controls_section();			
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$get_year = $settings['travail_countdown_year'] > 0 ? $settings['travail_countdown_year'] : '';
		$get_month = $settings['travail_countdown_month'] > 0 ? $settings['travail_countdown_month'] : '';
		$get_date = $settings['travail_countdown_date'] > 0 ? $settings['travail_countdown_date'] : '';
		$get_hour = $settings['travail_countdown_hour'] > 0 ? $settings['travail_countdown_hour'] : '';
		$get_minute = $settings['travail_countdown_minute'] > 0 ? $settings['travail_countdown_minute'] : '';
		$get_second = $settings['travail_countdown_second'] > 0 ? $settings['travail_countdown_second'] : '';
		$get_end_text = $settings['travail_countdown_end_text'] > 0 ? $settings['travail_countdown_end_text'] : '';
		$get_bg_img = $settings['travail_countdown_bgimage']['url'];
	?>
	<div class="travail-elementor-countdown-widget">

		<?php echo do_shortcode('[travail_countdown year='.$get_year.' month='.$get_month.' date='.$get_date.' hour='.$get_hour.' minute='.$get_minute.' second='.$get_second.' bgimage="'.$get_bg_img.'" endtext="'.$get_end_text.'"]');?>
	</div>
	<?php
}
}
