<?php
namespace Travail\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class TravailNewsletterWidget extends Widget_Base {

	public function get_name() {
		return 'travail-newsletter-widget';
	}

	public function get_title() {
		return __( 'Travail Newsletter', 'travail-elementor-kits' );
	}

	public function get_icon() {
		return 'eicon-mailchimp';
	}

	public function get_categories() {
		return [ 'travail-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'travail_newsletter_settings',
			[
				'label' => __( 'Travail Newsletter Settings', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'travail_newsletter_mailchimp_api',
			[
				'label' => __( 'MailChimp API Key','travail-elementor-kits' ),
				'description' => 'The unique API Key of your MailChimp account. <a href="https://mailchimp.com/help/about-api-keys/" target="_blank">Find Your API Key!</a>',
				'type' => Controls_Manager::TEXT,
				'default' => '',
			]
		);
		$this->add_control(
			'travail_newsletter_mailchimp_listid',
			[
				'label' => __( 'MailChimp List ID','travail-elementor-kits' ),
				'description' => 'The unique List ID of your MailChimp account. <a href="https://mailchimp.com/help/find-your-list-id/" target="_blank">Find Your List ID!</a>',				
				'type' => Controls_Manager::TEXT,
				'default' => '',
			]
		);
		$this->add_control(
			'travail_newsletter_double_optin_switch',
			[
				'label'   => __( 'On/Off MailChimp Double Optin', 'travail-elementor-kits' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'true',
				'options' => [
					'true'  => 'On',
					'false' => 'Off'
				],
			]
		);																		
        $this->end_controls_section();

		$this->start_controls_section(
			'travail_newsletter_style',
			[
				'label' => __( 'Travail Newsletter Style', 'travail-elementor-kits' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'travail_newsletter_notice_text_color',
			[
				'label' => __( 'Notice Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-newsletter-widget .mailchimp_result' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'divider1',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);				
		$this->add_control(
			'travail_newsletter_button_text_color',
			[
				'label' => __( 'Button Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-newsletter-widget .subscribe-btn' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'travail_newsletter_button_bg',
				'label' => __( 'Button Background', 'travail-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .travail-elementor-newsletter-widget .subscribe-btn',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->add_control(
			'travail_newsletter_button_hover_color',
			[
				'label' => __( 'Button Hover Text Color', 'travail-elementor-kits' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .travail-elementor-newsletter-widget .subscribe-btn:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'travail_newsletter_button_background_hover',
				'label' => __( 'Button Hover Background', 'travail-elementor-kits' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .travail-elementor-newsletter-widget .subscribe-btn:hover',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);        		        		       		        		        		        								
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'travail_newsletter_button_typography',
				'label' => __( 'Button Typography', 'travail-elementor-kits' ),
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_TEXT,
				],
				'selector' => '{{WRAPPER}} .travail-elementor-newsletter-widget .subscribe-btn',
			]
        );		
        $this->end_controls_section();		                
	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		$travail_newsletter_mailchimp_api = $settings['travail_newsletter_mailchimp_api'];
		$travail_newsletter_mailchimp_listid = $settings['travail_newsletter_mailchimp_listid'];
		$travail_newsletter_double_optin = $settings['travail_newsletter_double_optin_switch'];
	?>

	<div class="travail-elementor-newsletter-widget">
    <?php echo do_shortcode('[travail_newsletter api="'.$travail_newsletter_mailchimp_api.'" listid="'.$travail_newsletter_mailchimp_listid.'" double_optin="'.$travail_newsletter_double_optin.'"]'); ?>
	</div>

	<?php
}

}
