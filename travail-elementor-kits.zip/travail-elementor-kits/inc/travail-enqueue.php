<?php

/*****************************************************
Enqueue scripts
******************************************************/

function travail_ext_enqueue(){
	wp_enqueue_style('travail-elementor-style', TRAVAIL_ELEMENTOR_KITS_ASSETS . 'css/style.css?v='.TRAVAIL_ELEMENTOR_KITS_VERSION);
	wp_enqueue_style('travail-bootstrap-grid', TRAVAIL_ELEMENTOR_KITS_ASSETS . 'css/bootstrap-grid.min.css?v='.TRAVAIL_ELEMENTOR_KITS_VERSION);	
	wp_enqueue_style('travail-lightbox', TRAVAIL_ELEMENTOR_KITS_ASSETS . 'css/lightbox.css?v='.TRAVAIL_ELEMENTOR_KITS_VERSION);
	wp_enqueue_script('travail-custom', TRAVAIL_ELEMENTOR_KITS_ASSETS . 'js/travail.js?v='.TRAVAIL_ELEMENTOR_KITS_VERSION, array('jquery'), '1.0.0', true);
	wp_enqueue_script('travail-multi-countdown', TRAVAIL_ELEMENTOR_KITS_ASSETS . 'js/multi-countdown.js?v='.TRAVAIL_ELEMENTOR_KITS_VERSION, array('jquery'), '1.0.0', true);
	wp_enqueue_script('travail-lightbox', TRAVAIL_ELEMENTOR_KITS_ASSETS . 'js/lightbox.min.js?v='.TRAVAIL_ELEMENTOR_KITS_VERSION, array('jquery'), '1.0.0', true);
}

add_action('wp_enqueue_scripts', 'travail_ext_enqueue');
