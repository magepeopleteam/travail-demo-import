<?php
/*
Plugin Name: Travail Elementor Kits
Plugin URI: https://mage-people.com
Description: Widgets for Elementor
Version: 1.0
Author: MagePeople Team
Author URI: https://mage-people.com
Text Domain: travail-elementor-kits
Domain Path: /languages/
*/

define( 'TRAVAIL_ELEMENTOR_KITS_VERSION', '1.0' );
define( 'TRAVAIL_ELEMENTOR_KITS__FILE__', __FILE__ );
define( 'TRAVAIL_ELEMENTOR_KITS_DIR_URL', plugin_dir_url( TRAVAIL_ELEMENTOR_KITS__FILE__ ) );
define( 'TRAVAIL_ELEMENTOR_KITS_ASSETS', trailingslashit( TRAVAIL_ELEMENTOR_KITS_DIR_URL . 'assets' ) );

#-----------------------------------------------------------------
# Load Travail Functions
#-----------------------------------------------------------------

require_once 'inc/travail-functions.php';

#-----------------------------------------------------------------
# Load Scripts
#-----------------------------------------------------------------

require_once 'inc/travail-enqueue.php';

#-----------------------------------------------------------------
# Load Shortcodes
#-----------------------------------------------------------------

require_once 'inc/travail-shortcodes.php';

#-----------------------------------------------------------------
# Load Elementor Widgets
#-----------------------------------------------------------------

require_once 'modules/elementor-elements/elementor.php';

#-----------------------------------------------------------------
# Load Travail Icons
#-----------------------------------------------------------------

require_once 'inc/travail-icons.php';

#-----------------------------------------------------------------
# Load Travail Subscribe
#-----------------------------------------------------------------

require_once 'inc/travail-class-subscribe.php';