<?php
/***************************************************
Countdown Shortcode
****************************************************/
function travail_countdown_timer($atts){
	extract(shortcode_atts(array(
	'year'=>'',	
	'month'=>'',	
	'date'=>'',
	'hour'=>'',
	'minute'=>'',
	'second'=>'',
	'endtext'=>'',
	'bgimage'=>'',
	), $atts));

	$output= '<div class="countdown-time travail-countdown">';
	$output.= '<div class="countdown show" data-Date="'.esc_attr($year).'/'.esc_attr($month).'/'.esc_attr($date).' '.esc_attr($hour).':'.esc_attr($minute).':'.esc_attr($second).'" data-endText="'.esc_attr($endtext).'">
			  <div class="running">
			    <timer>
			      <div class="travail-count-wrapper" style="'; if($bgimage){ $output.='background-image:url('.$bgimage.');'; } $output.='"><span class="days number"></span> <span class="title">Days</span></div>

			      <div class="travail-count-wrapper" style="'; if($bgimage){ $output.='background-image:url('.$bgimage.');'; } $output.='"><span class="hours number"></span> <span class="title">Hours</span></div>

			      <div class="travail-count-wrapper" style="'; if($bgimage){ $output.='background-image:url('.$bgimage.');'; } $output.='"><span class="minutes number"></span> <span class="title">Minutes</span></div>

			      <div class="travail-count-wrapper" style="'; if($bgimage){ $output.='background-image:url('.$bgimage.');'; } $output.='"><span class="seconds number"></span> <span class="title">Seconds</span></div>
			    </timer>
			  </div>
			  </div>
			</div>';


	return $output;
}

add_shortcode('travail_countdown', 'travail_countdown_timer');

/**************************************************************** 
Pricing Table Shortcode 
*****************************************************************/

function travail_pricing_table( $atts ) {

extract( shortcode_atts( array(
	'plan_name'		 			=> '',
	'plan_currency'  			=> '',
	'plan_price'     			=> '',
	'plan_duration'  			=> '',
	'plan_enable_features'  	=> '',
	'plan_disable_features'  	=> '',
	'plan_btn_name'  			=> '',
	'plan_btn_url'   			=> '',
	'plan_card_icon'   			=> '',
	'plan_header_bg_image'   	=> '',
	'plan_body_bg_image'   		=> '',
	'plan_header_overlay_color' => '',
	'plan_currency_color'  		=> '',
	'plan_price_color'  		=> '',
	'plan_name_color'  			=> '',
	'plan_duration_color'  		=> '',
	'plan_feature_color'  		=> '',
	'plan_btn_text_color'  		=> '',
	'plan_btn_bg_color'  		=> ''	
	), $atts ) );

    $plan_all_enable_features 	= '';
    $plan_all_disable_features  = '';

	if (!empty($plan_enable_features)){
	$plan_all_enable_features 	= explode(",",$plan_enable_features);
	}

	if (!empty($plan_disable_features)){
	$plan_all_disable_features 	= explode(",",$plan_disable_features);
	}

	$output ='<section class="travail-pricing-table p-30-0-30">
							<div class="plan-item style-1">
								<div class="item-header" ';if($plan_header_bg_image) { $output.='style="background-image:url('.esc_url($plan_header_bg_image).')"'; } $output.='>
									<div class="overlay d-flex flex-column justify-content-center align-items-center tex-center" ';if($plan_header_overlay_color) { $output.='style="background-color:'.esc_attr($plan_header_overlay_color).'"'; } $output.='>

										';if($plan_card_icon) { $output.='
										<div class="card-image">
											<i class="'.$plan_card_icon.'"></i>
										</div>
										'; } $output.='

										';if($plan_name) { $output.='
										<h3 class="plan-name" ';if($plan_name_color) { $output.='style="color:'.esc_attr($plan_name_color).'"'; } $output.='>'.esc_attr($plan_name).'</h3>
										'; } $output.='

										<div class="plan-price">
											';if($plan_currency) { $output.='
											<span class="curency" '; if($plan_currency_color) { $output.='style="color:'.esc_attr($plan_currency_color).'"'; } $output.='>'.esc_attr($plan_currency).'</span>
											'; } $output.='

											';if($plan_price) { $output.='
											<span class="price-number" '; if($plan_price_color) { $output.='style="color:'.esc_attr($plan_price_color).'"'; } $output.='>'.esc_attr($plan_price).'</span>
											'; } $output.='

											';if($plan_duration) { $output.='
											<span class="plan-period" ';if($plan_duration_color) { $output.='style="color:'.esc_attr($plan_duration_color).'"'; } $output.='>'.esc_attr($plan_duration).'</span>
											'; } $output.='
										</div>
									</div>
								</div>
								
								<div class="item-content" ';if($plan_body_bg_image) { $output.='style="background-image:url('.esc_url($plan_body_bg_image).')"'; } $output.='>
									<div class="content-overlay">

									';if($plan_all_enable_features) { $output.='
										<ul>'; 	
										$c = -1;
										foreach($plan_all_enable_features as $feature) {
										$c++;
										$output .= '<li class="true"'; if($plan_feature_color) { $output.='style="color:'.esc_attr($plan_feature_color).'"'; } $output.='>'.htmlspecialchars_decode($feature).'</li>';
										} $output.='</ul>
                                    '; } $output.='

									';if($plan_all_disable_features) { $output.='
										<ul class="mt-m-25">'; 	
										$c = -1;
										foreach($plan_all_disable_features as $feature) {
										$c++;
										$output .= '<li class="false"'; if($plan_feature_color) { $output.='style="color:'.esc_attr($plan_feature_color).'"'; } $output.='>'.htmlspecialchars_decode($feature).'</li>';
										} $output.='</ul>
                                    '; } $output.='

										<a href="'.esc_url($plan_btn_url).'" class="button button-secondary rounded-capsule button-block" '; if($plan_btn_text_color || $plan_btn_bg_color) { $output.='style="'; if($plan_btn_text_color) { $output.='color:'.esc_attr($plan_btn_text_color).';'; } if($plan_btn_bg_color) { $output.='background-color:'.esc_attr($plan_btn_bg_color).''; } $output.='"'; } $output.='>
											'.esc_attr($plan_btn_name).' 
										</a>
									</div>
								</div>															
							</div>
			</section>';
	
    return $output;
}

add_shortcode('travail_pricing_table', 'travail_pricing_table');

/**************************************************************** 
Blog Section Shortcode 
*****************************************************************/

function travail_blog( $atts ) {

    extract(shortcode_atts(array(
    'category'   => '',
    'num_post'   => '6',
    'word_limit' => '15',
    'order'      => 'DESC',
    'orderby'    => 'post_date',
    'date_format'=> 'style1',
    ), $atts));

	$args = array(
			'posts_per_page' => $num_post ,
			'cat' 			 => $category,
			'order' 		 => $order,
			'orderby'        => $orderby,
			'post_status'    => 'publish',
			);

	global $wp_query;		
	$temp_query = $wp_query;
	$wp_query= null;			
	$wp_query = new WP_Query($args);

	$output = '<section class="travail-blog-section">
			   <div class="container">
			   <div class="row">';

	if ($wp_query->have_posts()) :  while ($wp_query->have_posts()) : $wp_query->the_post();
	global $post;
	$postid = $post->ID;
	$get_image = wp_get_attachment_url( get_post_thumbnail_id() );	
	
	$output.= '<div class="col-md-4">
						<article class="blog-post-item-1">
							<div class="travail-blog-thumbnail animate-zoom">'; 

							if($get_image){ $output.='
							   <a href="'.esc_url(get_the_permalink()).'">
								  <div class="blog-p-f-img" style="background-image: url('.esc_url($get_image).'); background-position: center;background-size:cover"></div>
							   </a>'; 
							} 

                         	if($date_format == 'wp'){

								if(function_exists('vek_blog_wp_date_meta')){

									$output.= vek_blog_wp_date_meta();

								}

							} elseif($date_format == 'style1') {

							   if(function_exists('vek_blog_style_date_meta')){

							   		$output.= vek_blog_style_date_meta();

								}

							}								   
								
							$output.= '</div>
							<div class="post-author-n-comments">';

								if(function_exists('vek_blog_author_meta')) {

									$output.= vek_blog_author_meta();

								}

								if(function_exists('vek_blog_comments_meta')) {

									$output.= vek_blog_comments_meta($postid);

								}								
							$output.= '</div>'; 
							$output.= '<div class="post-content">';
							if(get_the_title()){

							$output.= '<a href="'.esc_url(get_the_permalink()).'">
										<h3 class="post-title">
											'.esc_attr(get_the_title()).'
										</h3>
							          </a>'; 
							} $output.='

							<p class="post-excerpt m-0">'; 
							if ( has_post_format( 'video' ) ) {

								$output.= vek_blog_content($word_limit);

							} else {

								$output.= vek_blog_excerpt($word_limit);

							}
							$output.= '</p>
							</div>
						</article>
				</div>';
	

	endwhile;endif;	
	$wp_query = null;
	$wp_query = $temp_query;
	wp_reset_query();
		
	$output.='</div>
			</div>
		</section>';

	return $output;
}

add_shortcode('travail_blog', 'travail_blog');

/**************************************************************** 
Newsletter Shortcode 
*****************************************************************/

function travail_newsletter($atts){
	extract(shortcode_atts(array(
	'api'=>'',	
	'listid'=>'',
	'double_optin'=>'',
	), $atts));

	$output = '<section>';
	$output.= '<form class="form-inline travail-newsletter-form">
				  <div class="form-group mx-sm-3">
				    <input type="email" class="form-control" name="email" id="mailchimp_email" placeholder="Enter your email here" required>
				    <div class="mailchimp_result"></div>
				  </div>
				  <button type="submit" class="subscribe-btn">'.esc_html__('Subscribe','travail-elementor-kits').' <i class="fas"></i></button>
				   <input type="hidden" id="mailchimp_api" name="mailchimp_api" value="'.esc_attr($api).'">
                   <input type="hidden" id="mailchimp_listid" name="mailchimp_listid" value="'.esc_attr($listid).'">
                   <input type="hidden" id="mailchimp_double_optin" name="mailchimp_double_optin" value="'.esc_attr($double_optin).'">
				</form>';
	$output.= '</section>';

	return $output;
}

add_shortcode('travail_newsletter', 'travail_newsletter');

/**************************************************************** 
Contact Form Shortcode 
*****************************************************************/

function travail_contact_form($atts){
	extract(shortcode_atts(array(
	'subject'=>'',	
	'recipient'=>'',
	'btn_label'=>'Send Message',
	), $atts));

	$output = '<section>';
	$output.='<form method="POST" id="travail_contactform">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<input type="text" class="form-control" name="name" id="vek_cf_name" placeholder="'.esc_attr__('Name','travail-elementor-kits').'" required>
						</div>
					</div>
					<div class="col-md-6"> 
						<div class="form-group">
							<input type="email" class="form-control" name="email" id="vek_cf_email" placeholder="'.esc_attr__('Email','travail-elementor-kits').'" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<textarea name="message" class="form-control" id="vek_cf_message" cols="30" rows="7" placeholder="'.esc_attr__('Message','travail-elementor-kits').'" required></textarea>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<button type="submit" id="vek_cf_btn" class="btn btn-primary">'.esc_html($btn_label).' <i class="fas"></i></button>
						</div>
					</div>
				</div>
				<div class="vek_cf_result"></div>
				<input type="hidden" id="vek_cf_recipient" name="recipient" value="'.esc_attr($recipient).'">
				<input type="hidden" id="vek_cf_subject" name="subject" value="'.esc_attr($subject).'">
			</form>';
	$output.= '</section>';

	return $output;
}

add_shortcode('travail_contact_form', 'travail_contact_form');