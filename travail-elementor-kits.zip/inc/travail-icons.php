<?php

defined( 'ABSPATH' ) || die();

class Travail_Icons_Manager {

    public static function init() {
        add_filter( 'elementor/icons_manager/additional_tabs', [ __CLASS__, 'add_travail_icons_tab' ] );
    }

    public static function add_travail_icons_tab( $tabs ) {
        $tabs['travail-icons'] = [
            'name' => 'travail-icons',
            'label' => __( 'Travail Flaticons', 'travail-elementor-addons' ),
            'url' => TRAVAIL_ELEMENTOR_KITS_ASSETS . 'fonts/flaticon/flaticon.css?v='.TRAVAIL_ELEMENTOR_KITS_VERSION,
            'enqueue' => [ TRAVAIL_ELEMENTOR_KITS_ASSETS . 'fonts/flaticon/flaticon.css?v='.TRAVAIL_ELEMENTOR_KITS_VERSION ],
            'prefix' => 'flaticon-',
            'labelIcon' => 'flaticon-setting',
            'ver' => TRAVAIL_ELEMENTOR_KITS_VERSION,
            'fetchJson' => TRAVAIL_ELEMENTOR_KITS_ASSETS . 'fonts/flaticon/travail-flat-icons.js?v=' . TRAVAIL_ELEMENTOR_KITS_VERSION,
            'native' => false,
        ];
        return $tabs;
    }
}

Travail_Icons_Manager::init();